from stat_funcs import StatsN2
import pytest
from conftestes import lista

obj = StatsN2


valor = [2,4,6,7,3]

@pytest.mark.certa()
def test_dpadrao_certo():
    obj = StatsN2

    resultado =  obj.dpadrao(9)
    assert resultado == 3.0  #certo

@pytest.mark.xfail
def test_dpadrao():
    obj = StatsN2

    resultado =  obj.dpadrao(25)
    assert resultado == 80.0 








