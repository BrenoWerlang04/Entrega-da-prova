from stat_funcs import StatsN2
import pytest
from conftestes import lista


@pytest.mark.certa()
def test_skew():
    
    obj = StatsN2
    resultado =  obj.skew(lista)
    assert resultado == "Distribuição positiva" #certo

@pytest.mark.xfail
def test_skew():
    
    obj = StatsN2
    resultado =  obj.skew(lista)
    assert resultado == "Distribuição positiva" 