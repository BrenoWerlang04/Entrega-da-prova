from stat_funcs import StatsN2
import pytest

lista = [6,5,8,5,6] 


