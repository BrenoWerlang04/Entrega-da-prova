from stat_funcs import StatsN2
import pytest
from conftestes import lista

@pytest.mark.certa()
def test_amodal_certa():
    
    obj = StatsN2
    resultado =  obj.amodal(lista)
    assert resultado == 'Existe moda' 


@pytest.mark.xfail
def test_amodal():
    obj = StatsN2

    resultado =  obj.amodal(lista)
    assert resultado == 'Não existe moda'


