from stat_funcs import StatsN2
import pytest
from conftestes import lista


@pytest.mark.certa()
def test_variancia():
    
    obj = StatsN2
    resultado =  obj.variancia(lista)
    assert resultado == 1.5 #certo


@pytest.mark.xfail
def test_variancia():
    
    obj = StatsN2
    resultado =  obj.variancia(lista)
    assert resultado == 2.5 