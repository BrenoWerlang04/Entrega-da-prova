from stat_funcs import StatsN2
import pytest
from conftestes import lista

lista = [6,5,8,5,6] 

@pytest.mark.certa()
def test_unimodal():
    
    obj = StatsN2
    resultado =  obj.unimodal(lista)
    assert resultado == 'Não é unimodal' # certo

@pytest.mark.xfail
def test_unimodal():
    
    obj = StatsN2
    resultado =  obj.unimodal(lista)
    assert resultado == 'Erro' 