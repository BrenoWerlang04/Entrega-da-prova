from stat_funcs import StatsN2
import pytest
from conftestes import lista




@pytest.mark.certa()
def test_mediana():
    
    obj = StatsN2
    resultado =  obj.mediana(lista)
    assert resultado == 8

@pytest.mark.xfail
def test_mediana():
    
    obj = StatsN2
    resultado =  obj.mediana(lista)
    assert resultado == 50.5 