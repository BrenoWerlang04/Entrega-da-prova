from stat_funcs import StatsN2
import pytest
from conftestes import lista



@pytest.mark.certa()
def test_multimodal():
    
    obj = StatsN2
    resultado =  obj.multimodal(lista)
    assert resultado == 'É multimodal'

@pytest.mark.xfail
def test_multimodal():
    
    obj = StatsN2
    resultado =  obj.multimodal(lista)
    assert resultado == 'Não é multimodal'