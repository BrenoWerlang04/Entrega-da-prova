
from stat_funcs import StatsN2
import pytest
from conftestes import lista


valor = [2,4,6,7,3]

@pytest.mark.certa()
def test_media_ponderada():
    
    obj = StatsN2
    resultado =  obj.media_ponderada(lista,valor)
    assert resultado == 6.045454545454546 #certo

@pytest.mark.xfail
def test_media_ponderada():
    
    obj = StatsN2
    resultado =  obj.media_ponderada(lista,valor)
    assert resultado == 90.0 